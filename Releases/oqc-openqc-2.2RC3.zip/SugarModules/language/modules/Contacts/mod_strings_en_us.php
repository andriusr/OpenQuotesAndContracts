<?php

$mod_strings = array_merge($mod_strings,
	array(
		 'LBL_OQC_OFFERING_SUBPANEL_TITLE' => "oqc_Quotes",
		 'LBL_OQC_CONTRACT_SUBPANEL_TITLE' => "oqc_Contracts",
		 'LBL_OQC_PRODUCT_SUBPANEL_TITLE' => "oqc_Products",
		 'LBL_OQC_ADDITION_SUBPANEL_TITLE' => "oqc_Additions",
		 'LBL_OQC_EXTERNALCONTRACT_SUBPANEL_TITLE' => "oqc_ExternalContract",
		 'LBL_OQC_EXTERNAL' => 'Is Supplier?',
	)
);
?>
