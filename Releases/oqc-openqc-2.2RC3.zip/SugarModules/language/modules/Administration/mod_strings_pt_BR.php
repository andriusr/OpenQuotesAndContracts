<?php

$mod_strings = array_merge($mod_strings,
	array(
		 'LBL_OQC_TITLE' => "Editar arquivo de configuração",
		 'LBL_OQC_SETTINGS' => "OQC Editor de Arquivo de Configuração",
		 'LBL_OQC_HEADER' => "Open Quotes And Contracts",
		 'LBL_OQC_DESCRIPTION' => "Editar Parâmetros de Arquivo de Configuração",
		 'LBL_OQC_TASK_CONFIG_HINT' => 'Configurar Usuários que serão inclusos em TeamTasks por padrão',
		 'LBL_OQC_CONFIG_USERS_TITLE' => 'Editar usuários padrão de TeamTasks',
		 'LBL_OQC_CLEAN_UP_TITLE'=> 'Limpar database',
		 'LBL_OQC_CLEAN_UP_HINT' => 'Remover ou apagar versões antigas de Produtos, Propostas ou Contratos do database',

	)
);
?>
