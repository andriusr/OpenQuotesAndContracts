<?php

$mod_strings = array_merge($mod_strings,
	array(
		 'LBL_OQC_TITLE' => "Редактировать конфигурационный файл",
		 'LBL_OQC_SETTINGS' => "Openqc редактор конфигурационных файлов",
		 'LBL_OQC_HEADER' => "Open Quotes And Contracts",
		 'LBL_OQC_DESCRIPTION' => "Настройки редактирования конфигурационного файла",
		 'LBL_OQC_TASK_CONFIG_HINT' => 'Задайте пользователей, которые будут включены в групповые задания по-умолчанию',
		 'LBL_OQC_CONFIG_USERS_TITLE' => 'Изменить пользователей группового задания',
		 'LBL_OQC_CLEAN_UP_TITLE'=> 'Очистить базу данных',
		 'LBL_OQC_CLEAN_UP_HINT' => 'Удалить старые версии продуктов, предложений и контрактов из базы данных',

	)
);
?>
