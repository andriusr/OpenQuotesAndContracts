<?php
interface Highlightable {
	public function getHighlightningColor($max, $value);
}
?>