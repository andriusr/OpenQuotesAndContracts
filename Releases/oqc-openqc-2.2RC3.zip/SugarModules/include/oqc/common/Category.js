
function Category(id, name, description) {
	this.id = id;
	this.name = name;
	this.description = description;
}

	/*
	if (container) {
				


		var id = "categoryName" + this.id;
		var name = "categoryName[]";
		var value = this.name;
		var type = "hidden";
		var size = "1";
		var textAlign = "left";
			
		var nameHiddenField = getInputField(id, name, value, type, size, textAlign);

		var id = "categoryDescription" + this.id;
		var name = "categoryDescription[]";
		var value = this.description;
		var type = "hidden";
		var size = "1";
		var textAlign = "left";
			
		var descriptionHiddenField = getInputField(id, name, value, type, size, textAlign);
	}
		*/
