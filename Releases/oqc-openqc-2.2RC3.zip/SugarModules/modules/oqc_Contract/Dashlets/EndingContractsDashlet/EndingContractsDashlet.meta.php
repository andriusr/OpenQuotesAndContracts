<?php
$dashletMeta['EndingContractsDashlet'] = array(
	'title'       => translate('LBL_ENDINGCONTRACTS', 'oqc_Contract'),                                        
	'description' => translate('LBL_ENDINGCONTRACTS_DESCRIPTION', 'oqc_Contract'),
	'icon'        => 'themes/default/images/icon_DetailView.gif', 
	'category'    => 'Tools'
);
?>
